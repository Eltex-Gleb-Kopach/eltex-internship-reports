#!/bin/bash

WORKDIR="$(cd "$(dirname "$0")" && pwd)"
FIFO="/tmp/run/cuckoo.pid"
LOG="$WORKDIR/cuckoo.log"

mkdir -p /tmp/run
rm -f "$FIFO"
mkfifo "$FIFO"

log_message() {
    printf '%s %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$1" >> "$LOG"
}

shutdown() {
    log_message "Shutdown!"
    rm -f "$FIFO"
    exit 0
}

trap shutdown TERM

log_message "Startup!"

while true; do
    if read -r request < "$FIFO"; then
        if [[ "$request" =~ ^(.+)\[([0-9]+)\]:\ how\ much\ time\ do\ I\ have\?$ ]]; then
            name="${BASH_REMATCH[1]}"
            pid="${BASH_REMATCH[2]}"
            seconds=$((RANDOM % 9 + 2))

            log_message "${name}[${pid}] ${seconds}"

            reply_fifo="/tmp/run/${name}_${pid}.reply"

            if [[ -p "$reply_fifo" ]]; then
                printf '%s\n' "$seconds" > "$reply_fifo"
            fi
        fi
    fi
done
