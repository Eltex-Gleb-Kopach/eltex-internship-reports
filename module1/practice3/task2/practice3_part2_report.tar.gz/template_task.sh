#!/bin/bash

SCRIPT_NAME="$(basename "$0")"
TASK_NAME="${SCRIPT_NAME%.sh}"
WORKDIR="$(cd "$(dirname "$0")" && pwd)"
LOG="$WORKDIR/report_${TASK_NAME}.log"
PID="$$"
FIFO="/tmp/run/cuckoo.pid"
REPLY_FIFO="/tmp/run/${TASK_NAME}_${PID}.reply"

log_message() {
    printf '%s [%s] %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$PID" "$1" >> "$LOG"
}

if [[ "$SCRIPT_NAME" == "template_task.sh" ]]; then
    echo "я бригадир, сам не работаю"
    exit 0
fi

if [[ ! -p "$FIFO" ]]; then
    echo "Ошибка: канал $FIFO не найден"
    exit 1
fi

rm -f "$REPLY_FIFO"
mkfifo "$REPLY_FIFO"

log_message "Скрипт запущен"

printf '%s[%s]: how much time do I have?\n' "$TASK_NAME" "$PID" > "$FIFO"

if read -r seconds < "$REPLY_FIFO"; then
    sleep "$seconds"
    log_message "Скрипт завершился, работал ${seconds} секунд."
else
    rm -f "$REPLY_FIFO"
    exit 1
fi

rm -f "$REPLY_FIFO"
exit 0
