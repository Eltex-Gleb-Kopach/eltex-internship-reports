#!/bin/bash

WORKDIR="$(cd "$(dirname "$0")" && pwd)"
CONF="$WORKDIR/observer.conf"
LOG="$WORKDIR/observer.log"

log_message() {
    printf '%s %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$1" >> "$LOG"
}

is_running() {
    script_path="$1"
    script_name="$(basename "$script_path")"

    for proc_dir in /proc/[0-9]*; do
        if [[ -r "$proc_dir/cmdline" ]]; then
            cmdline="$(tr '\0' ' ' < "$proc_dir/cmdline")"

            if [[ "$cmdline" == *"$script_name"* ]]; then
                return 0
            fi
        fi
    done

    return 1
}

if [[ ! -f "$CONF" ]]; then
    log_message "Config file not found: $CONF"
    exit 1
fi

while IFS= read -r script_path; do
    [[ -z "$script_path" ]] && continue
    [[ "$script_path" == \#* ]] && continue

    if [[ "$script_path" != /* ]]; then
        full_path="$WORKDIR/$script_path"
    else
        full_path="$script_path"
    fi

    if [[ ! -x "$full_path" ]]; then
        log_message "Script not executable: $full_path"
        continue
    fi

    if ! is_running "$full_path"; then
        log_message "Restarting $full_path"
        nohup "$full_path" >/dev/null 2>&1 &
    fi
done < "$CONF"
